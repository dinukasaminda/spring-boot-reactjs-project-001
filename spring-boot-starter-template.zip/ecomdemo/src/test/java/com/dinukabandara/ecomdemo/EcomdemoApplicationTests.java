package com.dinukabandara.ecomdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
